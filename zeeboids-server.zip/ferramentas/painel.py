#!/usr/bin/env python3
"""
Um painel Qt para consultar o banco do servidor.

O `olhar_banco.py` é um log: passa e some. Este é o contrário — as tabelas se navegam, cada
linha se abre inteira, e dá para consultar com SQL. Lê o mesmo `var/zeeboids.db`, **somente para
leitura**, e se atualiza sozinho conforme as requisições chegam.

    python3 ferramentas/painel.py
    python3 ferramentas/painel.py -b /tmp/zb/zeeboids.db

Precisa do PyQt6 (`pacman -S python-pyqt6`). Ler em modo `ro` não é detalhe: a instância que
atende o jogo roda como root, e o painel não pode nem travar nem sujar o arquivo dela — inclusive
um `delete` digitado sem querer na caixa de SQL esbarra no SQLite, não no banco.
"""

import argparse
import os
import sqlite3
import sys

try:
    from PyQt6.QtCore import Qt, QTimer
    from PyQt6.QtGui import QAction, QColor, QFont, QKeySequence, QShortcut
    from PyQt6.QtWidgets import (
        QApplication, QCheckBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget,
        QListWidgetItem, QMainWindow, QPlainTextEdit, QPushButton, QSplitter,
        QStackedWidget, QTableWidget, QTableWidgetItem, QTextBrowser, QVBoxLayout, QWidget,
    )
except ImportError:
    sys.exit('falta o PyQt6:  pacman -S python-pyqt6   (ou  pip install PyQt6)')

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Os dez primeiros campos da linha do boneco, levantados em docs/protocolo.md. O resto ainda é
# hipótese, e por isso vai sem nome — numerado, que é como se olha para descobrir.
NOMES_DOS_CAMPOS = [
    'IMEI do console', '(sem nome)', 'id — negativo antes do export', 'senha (MD5)',
    'creator_IMEI', 'nickname', 'gender', 'birthday', 'creator_name', 'status',
]


# ---------------------------------------------------------------------- banco

def caminho_do_banco(dado=None):
    if dado:
        return dado
    var = os.environ.get('ZEEBOIDS_VAR') or os.path.join(RAIZ, 'var')
    return os.path.join(var, 'zeeboids.db')


def abre(caminho):
    uri = 'file:' + caminho.replace('?', '%3f').replace('#', '%23') + '?mode=ro'
    con = sqlite3.connect(uri, uri=True, timeout=5)
    con.row_factory = sqlite3.Row
    con.text_factory = bytes  # os corpos são cifrados; a decodificação é nossa
    return con


def nome(x):
    return x.decode() if isinstance(x, bytes) else x


def tabelas(con):
    return [nome(t[0]) for t in con.execute(
        "select name from sqlite_master where type='table' and name not like 'sqlite_%'"
        ' order by name')]


def colunas(con, tabela):
    return [nome(c[1]) for c in con.execute(f'pragma table_info("{tabela}")')]


def contagem(con, tabela):
    return tuple(con.execute(f'select count(*), coalesce(max(id), 0) from "{tabela}"'))[0]


def linhas(con, tabela, limite=500, busca=''):
    cols = colunas(con, tabela)
    sql = f'select * from "{tabela}"'
    args = []
    if busca:
        # `like` em coluna binária não casa; o `cast` resolve, e o custo é irrelevante no
        # tamanho que este banco tem.
        sql += ' where ' + ' or '.join(f'cast("{c}" as text) like ?' for c in cols)
        args += [f'%{busca}%'] * len(cols)
    sql += ' order by id desc limit ?'
    args.append(limite)
    return cols, list(con.execute(sql, args))


def uma_linha(con, tabela, ident):
    achado = list(con.execute(f'select * from "{tabela}" where id = ?', (ident,)))
    return achado[0] if achado else None


# ------------------------------------------------------------------- valores

def como_texto(v):
    """Devolve (texto, é_binário). O que chega do jogo é cifrado, e fingir que é texto atrapalha."""
    if v is None:
        return '—', False
    if isinstance(v, (int, float)):
        return str(v), False
    if isinstance(v, bytes):
        try:
            t = v.decode('utf-8')
            if not any(ord(c) < 32 and c not in '\t\n\r' for c in t):
                return t, False
        except UnicodeDecodeError:
            pass
        return f'{len(v)} bytes · ' + v.hex(' '), True
    return v, False


def curto(v, limite=140):
    t, binario = como_texto(v)
    t = t.replace('\n', '⏎').replace('\r', '')
    return (t[:limite] + '…') if len(t) > limite else t, binario


def despejo(b):
    """Hexadecimal em blocos de 16, com o ASCII do lado — o formato em que se lê um corpo cru."""
    linhas_ = []
    for i in range(0, len(b), 16):
        pedaco = b[i:i + 16]
        hexa = ' '.join(f'{x:02x}' for x in pedaco).ljust(47)
        letras = ''.join(chr(x) if 32 <= x < 127 else '.' for x in pedaco)
        linhas_.append(f'{i:04x}  {hexa}  {letras}')
    return '\n'.join(linhas_)


def escapa(s):
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def detalhe_html(tabela, linha):
    """A linha inteira, em duas colunas: o nome da coluna e o valor.

    Tabela e não parágrafos: o detalhe é para ser varrido com o olho, e o espaçamento de
    parágrafo do Qt afasta tanto o rótulo do valor que a leitura vira rolagem.
    """
    d = dict(zip(linha.keys(), tuple(linha)))
    h = [f'<h3 style="margin:0">{escapa(tabela)} #{d.get("id")}</h3>',
         '<table cellspacing="0" cellpadding="3" width="100%">']
    for k, v in d.items():
        if k == 'id':
            continue
        if isinstance(v, bytes) and como_texto(v)[1]:
            # O despejo vai numa linha só dele, ocupando as duas colunas: são 16 bytes mais o
            # ASCII, e recuá-lo pela coluna do rótulo cortaria justamente o ASCII.
            valor = (f'{len(v)} bytes</td></tr><tr><td colspan="2">'
                     f'<pre style="margin:2px 0">{escapa(despejo(v))}</pre>')
        else:
            valor = escapa(como_texto(v)[0]).replace('\n', '<br>')
        # A largura fixa no rótulo é o que impede o despejo hexadecimal, que é largo, de
        # espremer a coluna da esquerda até uma letra por linha.
        h.append(f'<tr><td valign="top" align="right" width="88" style="opacity:.55">'
                 f'{escapa(k)}</td><td valign="top">{valor}</td></tr>')
    h.append('</table>')

    # O `campos` do boneco é a linha crua separada por `;`. Numerar é o que serve: a ordem dos
    # campos é justamente o que docs/protocolo.md ainda está levantando.
    crus = d.get('campos') or d.get('corpo')
    texto, binario = como_texto(crus) if crus is not None else ('', True)
    if not binario and ';' in texto:
        h.append('<p style="margin:12px 0 2px"><b>separado por ;</b></p>'
                 '<table cellspacing="0" cellpadding="2" width="100%">')
        for i, parte in enumerate(texto.split(';')):
            rotulo = NOMES_DOS_CAMPOS[i] if i < len(NOMES_DOS_CAMPOS) else ''
            h.append(f'<tr><td align="right" width="26" style="opacity:.55">{i}</td>'
                     f'<td>{escapa(parte)}</td>'
                     f'<td style="opacity:.55">{escapa(rotulo)}</td></tr>')
        h.append('</table>')
    return '\n'.join(h)


# --------------------------------------------------------------------- janela

NOVA = QColor(70, 190, 110, 60)  # o verde da linha recém-chegada, sobre claro ou sobre escuro


class Painel(QMainWindow):
    def __init__(self, con, caminho):
        super().__init__()
        self.con, self.caminho = con, caminho
        self.tabela = None
        self.ultimo = 0          # o maior id já mostrado, para saber o que é novo
        self.pendente = 0        # chegou coisa, mas a leitura está rolada: não puxar o tapete
        self.setWindowTitle('banco do Zeeboids')
        self.resize(1280, 760)

        mono = QFont('monospace')
        mono.setStyleHint(QFont.StyleHint.Monospace)

        # esquerda: as tabelas, e a consulta
        self.lista = QListWidget()
        self.lista.setMaximumWidth(220)
        self.lista.currentItemChanged.connect(self.escolhe)

        # centro: busca, tabela de linhas / caixa de SQL
        self.busca = QLineEdit(placeholderText='procurar em todas as colunas…')
        self.busca.textChanged.connect(self.adia_busca)
        self.aovivo = QCheckBox('ao vivo')
        self.aovivo.setChecked(True)
        self.novas = QPushButton('linhas novas ↑')
        self.novas.setVisible(False)
        self.novas.clicked.connect(self.mostra_novas)

        alto = QHBoxLayout()
        alto.setContentsMargins(0, 0, 0, 0)
        for w in (self.busca, self.novas, self.aovivo):
            alto.addWidget(w)

        self.grade = QTableWidget()
        self.grade.setFont(mono)
        self.grade.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.grade.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.grade.setAlternatingRowColors(True)
        self.grade.verticalHeader().setVisible(False)
        self.grade.currentCellChanged.connect(lambda l, *_: self.abre_detalhe(l))

        self.sql = QPlainTextEdit()
        self.sql.setFont(mono)
        self.sql.setPlaceholderText('select zid, apelido, imei from bonecos order by id desc')
        self.sql.setMaximumHeight(120)
        rodar = QPushButton('rodar  (ctrl+enter)')
        rodar.clicked.connect(self.roda_sql)
        QShortcut(QKeySequence('Ctrl+Return'), self.sql, self.roda_sql)
        caixa = QWidget()
        vs = QVBoxLayout(caixa)
        vs.setContentsMargins(0, 0, 0, 0)
        vs.addWidget(self.sql)
        vs.addWidget(rodar, alignment=Qt.AlignmentFlag.AlignLeft)

        self.pilha = QStackedWidget()
        self.pilha.addWidget(QWidget())          # 0: nada; a grade vive fora da pilha
        self.pilha.addWidget(caixa)              # 1: a caixa de SQL

        meio = QWidget()
        vm = QVBoxLayout(meio)
        vm.setContentsMargins(8, 8, 8, 8)
        vm.addLayout(alto)
        vm.addWidget(self.pilha)
        vm.addWidget(self.grade, 1)

        # direita: a linha inteira
        self.detalhe = QTextBrowser()
        self.detalhe.setFont(mono)
        self.detalhe.setMinimumWidth(560)  # o despejo hexadecimal tem 16 bytes por linha

        divisor = QSplitter()
        for w in (self.lista, meio, self.detalhe):
            divisor.addWidget(w)
        divisor.setSizes([180, 520, 580])
        self.setCentralWidget(divisor)

        self.status = QLabel()
        self.statusBar().addWidget(self.status)
        self.statusBar().addPermanentWidget(QLabel(f'{caminho}  ·  somente leitura'))

        sair = QAction(self, shortcut=QKeySequence('Ctrl+Q'), triggered=self.close)
        self.addAction(sair)
        QShortcut(QKeySequence('Ctrl+F'), self, lambda: self.busca.setFocus())

        self.atraso = QTimer(self, singleShot=True, interval=200)
        self.atraso.timeout.connect(self.carrega)
        self.relogio = QTimer(self, interval=2000)
        self.relogio.timeout.connect(self.espia)
        self.relogio.start()

        self.enche_lista()

    # -- lateral

    def enche_lista(self):
        atual = self.lista.currentItem().text() if self.lista.currentItem() else None
        self.lista.blockSignals(True)
        self.lista.clear()
        primeira = None
        for t in tabelas(self.con):
            n, _ = contagem(self.con, t)
            item = QListWidgetItem(t)
            item.setData(Qt.ItemDataRole.UserRole, t)
            item.setToolTip(f'{n} linhas')
            self.lista.addItem(item)
            if primeira is None and n:
                primeira = item
            if t == atual or t == self.tabela:
                self.lista.setCurrentItem(item)
        item = QListWidgetItem('SQL')
        item.setData(Qt.ItemDataRole.UserRole, None)
        self.lista.addItem(item)
        self.lista.blockSignals(False)
        if self.lista.currentRow() < 0:
            self.lista.setCurrentItem(primeira or self.lista.item(0))

    def escolhe(self, item, _=None):
        if item is None:
            return
        alvo = item.data(Qt.ItemDataRole.UserRole)
        self.detalhe.clear()
        self.novas.setVisible(False)
        self.pendente = 0
        if alvo is None:                       # a caixa de SQL
            self.tabela = None
            self.pilha.setCurrentIndex(1)
            self.pilha.setMaximumHeight(200)
            # Sem busca, sem ao-vivo e sem detalhe: aqui o resultado é a consulta, e ele fica
            # com a janela inteira.
            for w in (self.busca, self.aovivo, self.detalhe):
                w.setVisible(False)
            self.grade.setRowCount(0)
            self.grade.setColumnCount(0)
            self.sql.setFocus()
            self.status.setText('')
            return
        self.tabela = alvo
        self.pilha.setCurrentIndex(0)
        self.pilha.setMaximumHeight(0)
        for w in (self.busca, self.aovivo, self.detalhe):
            w.setVisible(True)
        self.carrega()

    # -- a grade

    def adia_busca(self):
        if self.tabela:
            self.atraso.start()

    def desenha(self, cols, achado, desde=None):
        self.grade.setUpdatesEnabled(False)
        self.grade.setColumnCount(len(cols))
        self.grade.setHorizontalHeaderLabels(cols)
        self.grade.setRowCount(len(achado))
        for l, linha in enumerate(achado):
            valores = tuple(linha)
            nova = desde is not None and 'id' in cols and valores[cols.index('id')] > desde
            for c, v in enumerate(valores):
                texto, binario = curto(v)
                cel = QTableWidgetItem(texto)
                if binario or v is None:
                    cel.setForeground(QColor(128, 128, 128))
                if nova:
                    cel.setBackground(NOVA)
                self.grade.setItem(l, c, cel)
        self.grade.resizeColumnsToContents()
        cab = self.grade.horizontalHeader()
        for c in range(len(cols)):
            if cab.sectionSize(c) > 420:
                cab.resizeSection(c, 420)
        cab.setSectionResizeMode(len(cols) - 1, QHeaderView.ResizeMode.Stretch)
        self.grade.setUpdatesEnabled(True)

    def carrega(self, desde=None):
        if not self.tabela:
            return
        busca = self.busca.text().strip()
        try:
            cols, achado = linhas(self.con, self.tabela, busca=busca)
        except sqlite3.Error as e:
            self.erro(str(e))
            return
        self.status.setStyleSheet('')
        self.desenha(cols, achado, desde)
        self.ultimo = max((l['id'] for l in achado), default=self.ultimo)
        if achado and self.grade.currentRow() < 0:
            self.grade.setCurrentCell(0, 0)  # o painel da direita já abre com alguma coisa
        self.status.setText(f'{len(achado)} linhas' + (f' · procurando "{busca}"' if busca else ''))
        self.novas.setVisible(False)
        self.pendente = 0

    def abre_detalhe(self, l):
        if l < 0 or not self.tabela or not self.grade.item(l, 0):
            return
        try:
            ident = int(self.grade.item(l, 0).text())
        except ValueError:
            return
        linha = uma_linha(self.con, self.tabela, ident)
        if linha is not None:
            self.detalhe.setHtml(detalhe_html(self.tabela, linha))

    # -- ao vivo

    def espia(self):
        if not self.aovivo.isChecked():
            return
        try:
            self.enche_lista()
            if not self.tabela:
                return
            _, ultimo = contagem(self.con, self.tabela)
        except sqlite3.Error:
            return  # o servidor pode estar no meio de uma escrita; a próxima volta pega
        if ultimo <= self.ultimo:
            return
        if self.grade.verticalScrollBar().value() > 0:
            # Rolagem no meio da leitura: não puxa o tapete de quem está lendo, avisa.
            self.pendente = ultimo
            self.novas.setVisible(True)
            return
        self.carrega(desde=self.ultimo)

    def mostra_novas(self):
        self.carrega(desde=self.ultimo)
        self.grade.scrollToTop()

    # -- SQL

    def roda_sql(self):
        texto = self.sql.toPlainText().strip()
        if not texto:
            return
        try:
            achado = list(self.con.execute(texto))
        except sqlite3.Error as e:
            # O `mode=ro` responde aqui: um `delete` sem querer esbarra no SQLite. O erro vai
            # para a barra, e não para um diálogo: quem está consultando digita errado o tempo
            # todo, e um modal a cada erro de vírgula seria um estorvo.
            self.erro(str(e))
            return
        cols = list(achado[0].keys()) if achado else []
        self.desenha(cols, achado)
        self.status.setStyleSheet('')
        self.status.setText(f'{len(achado)} linhas')

    def erro(self, texto):
        self.status.setStyleSheet('color: #d04040')
        self.status.setText(texto)


def main():
    p = argparse.ArgumentParser(description='Painel para consultar o banco do Zeeboids.')
    p.add_argument('-b', '--banco', help='caminho do .db (padrão: $ZEEBOIDS_VAR/zeeboids.db)')
    a = p.parse_args()

    caminho = caminho_do_banco(a.banco)
    if not os.path.exists(caminho):
        sys.exit(f'não há banco em {caminho} — ele nasce na primeira requisição do jogo.')

    app = QApplication(sys.argv)
    janela = Painel(abre(caminho), caminho)
    janela.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
