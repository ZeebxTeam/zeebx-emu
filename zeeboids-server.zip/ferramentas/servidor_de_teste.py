#!/usr/bin/env python3
"""Um substituto do servidor PHP, para testar enquanto o PHP não está instalado.

**Isto não é o servidor.** O servidor é o PHP em `publico/`, que é o que vai rodar de verdade.
Este arquivo existe porque o instrumento é urgente e a instalação do PHP não é: ele fala o mesmo
protocolo, grava no mesmo `var/requisicoes.log` e responde a mesma coisa, de modo que o que for
descoberto com ele valha para o outro.

Quando o PHP estiver de pé, este arquivo continua útil para uma coisa: conferir que os dois
respondem igual.

Uso:
    sudo python3 ferramentas/servidor_de_teste.py          # porta 80, que é a que o jogo pede
    python3 ferramentas/servidor_de_teste.py 8080          # sem privilégio, para curl
"""

import datetime
import http.server
import pathlib
import shutil
import sqlite3
import zlib
import subprocess
import sys

RAIZ = pathlib.Path(__file__).resolve().parent.parent
VAR = RAIZ / "var"
PREFIXO = "/zeeboidsService/PHP/Client/"


def banco():
    VAR.mkdir(exist_ok=True)
    db = sqlite3.connect(VAR / "zeeboids.db")
    db.execute(
        "CREATE TABLE IF NOT EXISTS exportados ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, recebido_em TEXT, corpo TEXT)"
    )
    db.execute(
        "CREATE TABLE IF NOT EXISTS sincronizacoes ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, recebido_em TEXT, imei TEXT, corpo TEXT)"
    )
    return db


# A chave com que o Zeeboids cifra o corpo antes de enviar: AES-128-CBC, IV zerado. É fixa, está
# no próprio jogo, e foi lida no emulador quando ele a configura pelo `ICipher1::SetParam`.
CHAVE = "00010203050607080a0b0c0d0f101112"


def decifra(corpo):
    """O corpo em claro, ou `None`. Usa o `openssl` do sistema para não trazer dependência."""
    if not corpo or len(corpo) % 16 or not shutil.which("openssl"):
        return None
    saida = subprocess.run(
        ["openssl", "enc", "-d", "-aes-128-cbc", "-K", CHAVE, "-iv", "0" * 32, "-nopad"],
        input=corpo, capture_output=True, check=False,
    )
    return saida.stdout or None


def desmonta(claro):
    """`deflate(texto) + IMEI de 15 caracteres + NUL`. Devolve `(texto, imei)`."""
    sem_zeros = claro.rstrip(b"\0")
    if len(sem_zeros) <= 15:
        return None, None
    imei, carga = sem_zeros[-15:], sem_zeros[:-15]
    try:
        return zlib.decompress(carga, -15).decode("latin1"), imei.decode("latin1")
    except zlib.error:
        return None, imei.decode("latin1")


def registrar(endpoint, metodo, cabecalhos, corpo):
    """Grava a requisição crua, no mesmo formato do `src/registro.php`."""
    VAR.mkdir(exist_ok=True)
    agora = datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%d %H:%M:%S")
    linhas = ["=" * 72, f"{agora}  {endpoint}  {metodo}"]
    linhas += [f"  {k}: {v}" for k, v in sorted(cabecalhos.items())]
    linhas.append(f"  corpo ({len(corpo)} bytes):")
    try:
        texto = corpo.decode("ascii")
    except UnicodeDecodeError:
        texto = None
    if texto is None:
        linhas.append("  não é texto imprimível; em hexadecimal:")
        linhas.append("    " + corpo.hex())
    elif texto:
        linhas.append(f"    {texto!r}")
        campos = texto.split(";")
        linhas.append(f'  {len(campos)} campo(s) separado(s) por ";":')
        linhas += [f"    [{i:2}] {c!r}" for i, c in enumerate(campos)]
    # O corpo em claro vem por último, porque é interpretação: se a chave mudar, o que está
    # acima continua sendo o que chegou.
    claro = decifra(corpo)
    if claro:
        texto, imei = desmonta(claro)
        linhas.append(f"  IMEI do console: {imei!r}")
        if texto is None:
            linhas.append(f"  decifrado, mas a carga não descomprimiu: {claro.hex()}")
        else:
            linhas.append(f"  carga (deflate -> {len(texto)} bytes):")
            linhas += [f"      [{i:2}] {c!r}" for i, c in enumerate(texto.split(";"))]
    with open(VAR / "requisicoes.log", "a") as f:
        f.write("\n".join(linhas) + "\n")
    print("\n".join(linhas[1:]), flush=True)


class Servidor(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        tamanho = int(self.headers.get("Content-Length") or 0)
        corpo = self.rfile.read(tamanho)
        endpoint = self.path.removeprefix(PREFIXO)
        registrar(endpoint, self.command, dict(self.headers), corpo)

        db = banco()
        agora = datetime.datetime.now(datetime.UTC).isoformat()
        texto = corpo.decode("latin1")
        if endpoint == "export.php":
            cur = db.execute(
                "INSERT INTO exportados (recebido_em, corpo) VALUES (?, ?)", (agora, texto)
            )
            db.commit()
            # O servidor é quem atribui os dois números: é o que o `UPDATE` do jogo grava depois.
            resposta = f"{cur.lastrowid};{100000 + cur.lastrowid};".encode()
        elif endpoint == "import.php":
            ident = texto.split(";")[0]
            achado = db.execute(
                "SELECT corpo FROM exportados WHERE id = ?", (ident or 0,)
            ).fetchone()
            resposta = (achado[0] if achado else "").encode("latin1")
        else:
            db.execute(
                "INSERT INTO sincronizacoes (recebido_em, imei, corpo) VALUES (?, ?, ?)",
                (agora, texto.split(";")[0], texto),
            )
            db.commit()
            # Vazio de propósito: uma resposta inventada faria o jogo gravar ranking falso.
            resposta = b""
        db.close()

        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(resposta)))
        self.end_headers()
        self.wfile.write(resposta)

    def do_GET(self):
        self.do_POST()

    def log_message(self, *_):
        pass  # O registro já diz tudo, e com mais detalhe.


def main():
    porta = int(sys.argv[1]) if len(sys.argv) > 1 else 80
    print(f"ouvindo em 0.0.0.0:{porta}; registro em {VAR / 'requisicoes.log'}", flush=True)
    http.server.HTTPServer(("0.0.0.0", porta), Servidor).serve_forever()


main()
