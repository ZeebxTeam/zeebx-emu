#!/usr/bin/env python3
"""
Olha o banco do servidor enquanto ele recebe.

O servidor grava cada requisição no `var/zeeboids.db` (veja `src/banco.php`). Este script abre
esse arquivo **somente para leitura** e fica esperando: cada linha nova que aparece em qualquer
tabela é impressa assim que chega. É o mesmo instrumento do `var/requisicoes.log`, só que do
lado de dentro, já separado por tabela.

    python3 ferramentas/olhar_banco.py                 # segue o que chegar
    python3 ferramentas/olhar_banco.py -n 5            # mostra as 5 últimas antes de seguir
    python3 ferramentas/olhar_banco.py -t bonecos      # só uma tabela
    python3 ferramentas/olhar_banco.py -i              # navegar: consultas à mão
    python3 ferramentas/olhar_banco.py --sql "select zid, apelido from bonecos"

O banco fica onde o `ZEEBOIDS_VAR` mandar, ou em `var/` ao lado do projeto — igual ao servidor.
Abrir em modo `ro` importa: a instância que atende o jogo costuma rodar como root, e este script
não pode nem travar nem sujar o arquivo dela.
"""

import argparse
import os
import sqlite3
import sys
import time

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def caminho_do_banco(dado=None):
    if dado:
        return dado
    var = os.environ.get('ZEEBOIDS_VAR') or os.path.join(RAIZ, 'var')
    return os.path.join(var, 'zeeboids.db')


def abre(caminho):
    """Somente leitura, e sem criar arquivo se ele ainda não existir."""
    uri = 'file:' + caminho.replace('?', '%3f').replace('#', '%23') + '?mode=ro'
    con = sqlite3.connect(uri, uri=True, timeout=5)
    con.row_factory = sqlite3.Row
    con.text_factory = bytes  # os corpos são binários; a decodificação é nossa
    return con


def espera_o_arquivo(caminho, silencioso=False):
    """O banco só nasce na primeira requisição. Então esperamos por ele."""
    if os.path.exists(caminho):
        return
    if not silencioso:
        print(f'esperando o banco aparecer em {caminho} ...', file=sys.stderr)
    while not os.path.exists(caminho):
        time.sleep(0.5)


def tabelas(con):
    return [
        t[0].decode() if isinstance(t[0], bytes) else t[0]
        for t in con.execute(
            "select name from sqlite_master where type='table' and name not like 'sqlite_%'"
            ' order by name'
        )
    ]


def colunas(con, tabela):
    return [
        c[1].decode() if isinstance(c[1], bytes) else c[1]
        for c in con.execute(f'pragma table_info("{tabela}")')
    ]


# ---------------------------------------------------------------- apresentação

CORES = sys.stdout.isatty() and os.environ.get('NO_COLOR') is None


def cor(texto, codigo):
    return f'\033[{codigo}m{texto}\033[0m' if CORES else texto


def legivel(valor, limite=160):
    """Um valor de coluna em uma linha só.

    Os corpos que chegam do jogo são cifrados: não são texto, e imprimi-los crus estraga o
    terminal. Quando não decodificam, viram tamanho e hexadecimal — que é o que se olha mesmo.
    """
    if valor is None:
        return cor('—', '2')
    if isinstance(valor, (int, float)):
        return str(valor)
    if isinstance(valor, bytes):
        try:
            texto = valor.decode('utf-8')
        except UnicodeDecodeError:
            hexa = valor[:24].hex(' ')
            reticencias = ' …' if len(valor) > 24 else ''
            return cor(f'<{len(valor)} bytes> {hexa}{reticencias}', '2')
        if any(c < 32 and c not in (9, 10, 13) for c in valor):
            hexa = valor[:24].hex(' ')
            return cor(f'<{len(valor)} bytes> {hexa} …', '2')
        valor = texto
    valor = valor.replace('\n', '⏎').replace('\r', '')
    if len(valor) > limite:
        valor = valor[:limite] + '…'
    return valor


def mostra(tabela, linha, campos_largos=('corpo', 'campos')):
    """Uma linha do banco, em bloco. Os campos largos vão por último, um por linha."""
    d = dict(zip(linha.keys(), tuple(linha)))
    ident = d.get('id')
    quando = legivel(d.get('recebido_em'), 40)
    print(f"{cor('▸ ' + tabela, '1;36')} #{ident}  {cor(quando, '2')}")
    curtos = [
        f'{k}={legivel(v, 60)}'
        for k, v in d.items()
        if k not in ('id', 'recebido_em') and k not in campos_largos and v is not None
    ]
    if curtos:
        print('   ' + '  '.join(curtos))
    for k in campos_largos:
        if k in d and d[k] is not None:
            print(f"   {cor(k, '2')}: {legivel(d[k])}")


def ultimas(con, tabela, n):
    linhas = list(con.execute(f'select * from "{tabela}" order by id desc limit ?', (n,)))
    return list(reversed(linhas))


# ------------------------------------------------------------------- seguir

def seguir(con, alvos, intervalo, marcas):
    """O laço. Pergunta pelas linhas com id maior que o último visto, e dorme."""
    print(cor(f"seguindo {', '.join(alvos)} — ctrl-c para sair", '2'), file=sys.stderr)
    while True:
        for tabela in alvos:
            try:
                novas = list(
                    con.execute(
                        f'select * from "{tabela}" where id > ? order by id', (marcas[tabela],)
                    )
                )
            except sqlite3.DatabaseError as e:
                # O servidor pode estar no meio de uma escrita, ou a tabela ainda não existe.
                print(cor(f'{tabela}: {e}', '33'), file=sys.stderr)
                continue
            for linha in novas:
                marcas[tabela] = linha['id']
                mostra(tabela, linha)
                print()
        sys.stdout.flush()
        time.sleep(intervalo)


def consulta(con, sql):
    try:
        linhas = list(con.execute(sql))
    except sqlite3.Error as e:
        print(cor(str(e), '31'), file=sys.stderr)
        return
    if not linhas:
        print(cor('(nada)', '2'))
        return
    nomes = linhas[0].keys()
    print(cor('  '.join(nomes), '1'))
    for linha in linhas:
        print('  '.join(legivel(v, 60) for v in tuple(linha)))
    print(cor(f'({len(linhas)} linhas)', '2'))


# ---------------------------------------------------------------- navegar

AJUDA = """comandos:
  tabelas              as tabelas do banco
  esquema [tabela]     o CREATE TABLE
  ultimas <tabela> [n] as últimas linhas (n=5)
  seguir [tabela ...]  espera o que chegar (ctrl-c volta para o prompt)
  <qualquer SQL>       roda a consulta
  sair
"""


def navegar(con, caminho, intervalo):
    print(cor(f'banco: {caminho}', '2'))
    print(AJUDA)
    while True:
        try:
            linha = input(cor('banco> ', '1;36')).strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not linha:
            continue
        palavras = linha.split()
        comando = palavras[0].lower()
        if comando in ('sair', 'quit', 'exit', '.sair'):
            return
        if comando in ('ajuda', 'help', '?'):
            print(AJUDA)
        elif comando == 'tabelas':
            for t in tabelas(con):
                n = list(con.execute(f'select count(*) from "{t}"'))[0][0]
                print(f'  {t}  {cor(str(n) + " linhas", "2")}')
        elif comando == 'esquema':
            alvo = palavras[1] if len(palavras) > 1 else None
            sql = 'select sql from sqlite_master where sql is not null'
            args = ()
            if alvo:
                sql += ' and name = ?'
                args = (alvo,)
            for (s,) in con.execute(sql, args):
                print((s.decode() if isinstance(s, bytes) else s) + ';\n')
        elif comando == 'ultimas':
            if len(palavras) < 2:
                print(cor('ultimas <tabela> [n]', '31'))
                continue
            n = int(palavras[2]) if len(palavras) > 2 else 5
            for l in ultimas(con, palavras[1], n):
                mostra(palavras[1], l)
                print()
        elif comando == 'seguir':
            alvos = palavras[1:] or tabelas(con)
            alvos = [t for t in alvos if t in tabelas(con)]
            marcas = {t: marca_atual(con, t) for t in alvos}
            try:
                seguir(con, alvos, intervalo, marcas)
            except KeyboardInterrupt:
                print()
        else:
            consulta(con, linha)


def marca_atual(con, tabela):
    return list(con.execute(f'select coalesce(max(id), 0) from "{tabela}"'))[0][0]


# ---------------------------------------------------------------------- main

def main():
    p = argparse.ArgumentParser(
        description='Olha o banco do servidor do Zeeboids enquanto as requisições chegam.'
    )
    p.add_argument('-b', '--banco', help='caminho do .db (padrão: $ZEEBOIDS_VAR/zeeboids.db)')
    p.add_argument('-t', '--tabela', action='append', help='só esta tabela (pode repetir)')
    p.add_argument('-n', '--ultimas', type=int, default=0, help='mostra as N últimas antes de seguir')
    p.add_argument('-s', '--intervalo', type=float, default=0.5, help='segundos entre olhadas')
    p.add_argument('-i', '--navegar', action='store_true', help='prompt para consultar à mão')
    p.add_argument('--sql', help='roda uma consulta e sai')
    a = p.parse_args()

    caminho = caminho_do_banco(a.banco)
    espera_o_arquivo(caminho, silencioso=bool(a.sql))
    con = abre(caminho)

    if a.sql:
        consulta(con, a.sql)
        return

    if a.navegar:
        navegar(con, caminho, a.intervalo)
        return

    todas = tabelas(con)
    alvos = a.tabela or todas
    desconhecidas = [t for t in alvos if t not in todas]
    if desconhecidas:
        print(cor(f"não há {', '.join(desconhecidas)} — só {', '.join(todas)}", '31'),
              file=sys.stderr)
        sys.exit(1)

    marcas = {}
    for t in alvos:
        fim = marca_atual(con, t)
        if a.ultimas:
            for l in ultimas(con, t, a.ultimas):
                mostra(t, l)
                print()
        marcas[t] = fim
    try:
        seguir(con, alvos, a.intervalo, marcas)
    except KeyboardInterrupt:
        print()


if __name__ == '__main__':
    main()
