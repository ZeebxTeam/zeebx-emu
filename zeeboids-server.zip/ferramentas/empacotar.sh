#!/bin/sh
# Faz o zip que o Portainer recebe.
#
# O Portainer procura o `docker-compose.yml` na **raiz** do arquivo, então o zip não pode ter uma
# pasta em volta — é por isso que este roteiro existe, em vez de "compacte a pasta aí".
#
#     ferramentas/empacotar.sh              # gera zeeboids-server.zip ao lado do projeto
#     ferramentas/empacotar.sh /tmp/z.zip
#
# Empacota o diretório de trabalho, e não o que está comitado: o zip é para subir agora, e
# esperar um commit para testar um ajuste no Dockerfile seria uma cerimônia sem serventia. O que
# fica de fora é o mesmo do `.dockerignore` — sobretudo o `var/`, que é o registro **desta**
# máquina e não tem o que fazer no servidor.
set -eu

raiz=$(cd "$(dirname "$0")/.." && pwd)
destino=${1:-$raiz/../zeeboids-server.zip}

cd "$raiz"
rm -f "$destino"
zip -qr "$destino" . \
    -x 'var/*' '.git/*' '*/__pycache__/*' '*.log' '*.code-workspace'

unzip -l "$destino" | grep -q ' docker-compose.yml$' || {
    echo 'sem docker-compose.yml na raiz do zip' >&2
    exit 1
}
echo "$destino"
