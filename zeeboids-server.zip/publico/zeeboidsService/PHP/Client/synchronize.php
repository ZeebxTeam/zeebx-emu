<?php
/**
 * `synchronize.php` — placares, conquistas e ranking.
 *
 * O corpo foi lido no código do jogo (`SynchronizeScreen.cpp`, função em `0x957d4`): começa pelo
 * **IMEI do console** — quinze caracteres, do `ISHELL_GetDeviceInfoEx` item `0x1c` —, segue de
 * `;` e das linhas pendentes.
 *
 * É o endpoint que alimenta as três tabelas que só vêm do servidor: `scores_top10`,
 * `scores_zeeboid_neighbours` e `zeeboid_achievement`. O `neighbours` traz `rank` absoluto, então
 * é o servidor que calcula posição, não só nota.
 *
 * Por ora responde vazio de propósito. Uma resposta inventada faria o jogo gravar ranking falso
 * no banco dele, e aí o registro de tráfego passaria a descrever o meu palpite em vez do jogo.
 */
require __DIR__ . '/../../../../src/registro.php';
require __DIR__ . '/../../../../src/variantes.php';
require __DIR__ . '/../../../../src/banco.php';

$corpo = registrar('synchronize.php');
$campos = explode(';', $corpo);
$imei = $campos[0] ?? '';

banco()?->prepare('INSERT INTO sincronizacoes (recebido_em, imei, corpo) VALUES (?, ?, ?)')
    ?->execute([gmdate('c'), $imei, $corpo]);

// O formato da resposta do synchronize ainda não está lido no código — é uma máquina de estados
// com marcadores, e o que falta é amarrar marcador a seção. Cada requisição usa uma candidata e
// o registro diz qual, como se fez no export e no import.
[$forma, $descricao] = variante('synchronize.php');
registrar_nota("resposta: $descricao -> " . var_export($forma, true));
responder($forma);
