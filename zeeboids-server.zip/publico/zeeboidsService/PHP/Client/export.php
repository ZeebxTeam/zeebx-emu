<?php
/**
 * `export.php` — publicar um Zeeboid.
 *
 * O que o jogo faz depois de exportar está no SQL dele, e é o que define esta resposta:
 *
 *     UPDATE zeeboids SET id=%d, zid=%d, usable=1 WHERE lid=%d;
 *
 * Ou seja, **o servidor atribui o `id` e o `zid`** e devolve os dois. O `zid` é o número público,
 * o que aparece na tela como `ZID: %d` e nos rankings.
 *
 * A ordem `id;zid;` é a do `UPDATE`, e é hipótese: nada no binário obriga a resposta a ter a
 * mesma ordem do SQL. O registro dirá — se o jogo aceitar e mostrar o ZID certo, estava certa.
 */
require __DIR__ . '/../../../../src/registro.php';
require __DIR__ . '/../../../../src/banco.php';
require __DIR__ . '/../../../../src/variantes.php';
require __DIR__ . '/../../../../src/zeeboids.php';

$corpo = registrar('export.php');
$campos = campos_da_requisicao();
if ($campos === null) {
    // Sem carga legível não há o que guardar, e inventar um id seria pior: o jogo passaria a
    // acreditar num boneco que o servidor não tem.
    registrar_nota('sem carga legível: nada guardado');
    responder('');
    return;
}

[$id, $zid] = guardar($campos);
registrar_nota("guardado: id=$id zid=$zid apelido=" . var_export($campos[CAMPO_APELIDO] ?? '', true));

// Enquanto o formato da resposta não estiver decidido, cada requisição usa uma variante
// diferente e o registro diz qual — ver `src/variantes.php`. Os números são os de verdade.
// O `lid` é o identificador local do console. Ele vem no pedido e volta na resposta: o jogo o
// usa como chave do `UPDATE`, e só ele sabe qual é.
$lid = (string) ($campos[CAMPO_LID] ?? '0');
[$forma, $descricao] = variante('export.php');
$corpo_resposta = strtr($forma, [
    '{lid}' => $lid,
    '{id}' => (string) $id,
    '{zid}' => (string) $zid,
]);
registrar_nota("resposta: $descricao -> " . var_export($corpo_resposta, true) . " (lid do pedido: $lid)");

responder($corpo_resposta);
