<?php
/**
 * `import.php` — trazer um Zeeboid de outro console.
 *
 * O pedido, de uma captura real, é `?;IMEI;lid;ZID;senha` — a busca é pelo **`zid`**, o número
 * público que o jogador digita, e não pelo `id` interno. Isso desmente a suposição antiga de
 * `id;senha`, tirada do formato `%d;%s` que está colado na URL deste endpoint no binário.
 *
 * Chega no mesmo envelope do `export` — cifrado sobre `deflate` —, então o registro já o entrega
 * em campos.
 *
 * A resposta devolve **a lista que o próprio jogo exportou**, com o `id` e o `zid` preenchidos.
 * Devolver o que ele mesmo escreveu é a forma mais segura de acertar o formato: ele sabe ler.
 *
 * Não achando o boneco, ou errando a senha, responde vazio. É o "não encontrei" mais honesto —
 * melhor o jogo dizer que não achou do que receber um boneco inventado. Quando os códigos de
 * erro estiverem confirmados, aqui é onde eles entram: o consumidor do import testa `-1001`,
 * `-1002` e `-1005` no campo devolvido por `0x85b28`.
 */
require __DIR__ . '/../../../../src/registro.php';
require __DIR__ . '/../../../../src/zeeboids.php';
require __DIR__ . '/../../../../src/variantes.php';

$corpo = registrar('import.php');
$campos = campos_da_requisicao();
if ($campos === null) {
    registrar_nota('sem carga legível: nada a procurar');
    responder('');
    return;
}

$zid = (int) ($campos[PEDIDO_ZID] ?? 0);
$senha = (string) ($campos[PEDIDO_SENHA] ?? '');
$achado = buscar($zid, $senha);
// Achando o boneco, a forma da resposta ainda é hipótese: o jogo recebe os campos sem reclamar
// e sem aceitá-los, o que aponta para a ordem e não para o transporte. Cada requisição usa uma
// variante e o registro diz qual — ver `src/variantes.php`.
if (is_string($achado)) {
    // O `lid` é o que o console reservou para o boneco que vai chegar: ele o manda no pedido e
    // espera de volta, porque é a chave com que grava.
    $lid = (string) ($campos[PEDIDO_LID] ?? '0');
    $lista = explode(';', $achado);
    [$forma, $descricao] = variante('import.php');
    $resposta = strtr($forma, [
        '{lid}' => $lid,
        '{id}' => (string) ($lista[CAMPO_ID] ?? '0'),
        '{zid}' => (string) $zid,
        // Os dados do boneco começam depois dos três primeiros campos, que são justamente os
        // números que o trio acima já carrega.
        '{dados}' => implode(';', array_slice($lista, 3)),
    ]);
    registrar_nota("resposta: $descricao (lid do pedido: $lid)");
} else {
    $resposta = $achado === null ? erro(ERRO_NAO_ENCONTRADO) : erro(ERRO_NAO_AUTORIZADO);
}
$como = match (true) {
    $achado === null => 'não encontrado -> NotInOrbit',
    $achado === false => 'senha não confere -> Unauthorized',
    default => 'encontrado',
};
registrar_nota("import: zid=$zid $como");

responder($resposta);
