<?php
/**
 * Os Zeeboids guardados, e como devolvê-los.
 *
 * O `export` manda o boneco inteiro numa lista separada por `;`, e o `import` precisa devolver
 * essa mesma lista para outro console. Então o que se guarda é **a lista como chegou**, além dos
 * campos avulsos que servem para procurar. Devolver o que o próprio jogo produziu é a forma mais
 * segura de acertar o formato: ele sabe ler o que ele mesmo escreveu.
 *
 * O que o servidor decide são dois números — o `id` e o `zid` —, porque é o que o jogo grava
 * depois de exportar:
 *
 *     UPDATE zeeboids SET id=%d, zid=%d, usable=1 WHERE lid=%d;
 */

require_once __DIR__ . '/banco.php';

/**
 * As posições dos campos no pedido de **importação**, de uma captura real:
 *
 * ```
 * 0 ; 350000000000006 ; -5 ; 100001 ; 6512BD43D9CAA6E02C990B0A82652DCA
 * ?        IMEI         lid    ZID              senha em MD5
 * ```
 *
 * Isto desmente o levantamento antigo, que supunha `id;senha` a partir do formato `%d;%s` colado
 * na URL deste endpoint. **A busca é pelo `zid`**, que é o número público — o que o jogador
 * digita —, e não pelo `id` interno. Faz sentido: o `id` ninguém vê.
 */
const PEDIDO_IMEI = 1;
const PEDIDO_LID = 2;
const PEDIDO_ZID = 3;
const PEDIDO_SENHA = 4;

/** As posições dos campos do boneco na lista, levantadas de uma exportação real. */
const CAMPO_IMEI = 0;
/// O identificador **local**, que só o console conhece. É a chave do `UPDATE` que ele faz depois
/// de exportar, e por isso volta na resposta.
///
/// É o campo 1, não o 2: o 2 é o `id`, que chega negativo enquanto o boneco não foi exportado —
/// `-2` na captura —, e esse padrão é justamente o que o distingue.
const CAMPO_LID = 1;
const CAMPO_ID = 2;
const CAMPO_SENHA = 3;
const CAMPO_CRIADOR_IMEI = 4;
const CAMPO_APELIDO = 5;
const CAMPO_GENERO = 6;
const CAMPO_ANIVERSARIO = 7;
const CAMPO_CRIADOR = 8;
const CAMPO_STATUS = 9;

/**
 * Os códigos de erro, lidos da tela de import do jogo.
 *
 * A resposta de erro é `-1000;<código>;`: o campo 0 igual a `-1000` diz "deu errado", e o campo 1
 * traz o código, que o jogo guarda e consulta pelo getter em `0x85b28`.
 *
 * O que cada um mostra saiu da tabela de estados do `ImportScreen`, em `0x7aee8`, cruzada com os
 * pop-ups que cada tratador abre:
 *
 * | código | estado | pop-up |
 * |---|---|---|
 * | `-1001`, `-1002` | 5 | `Unauthorized` |
 * | `-1005` | 6 | `NotInOrbit` |
 *
 * Então `NotInOrbit` é "não existe aqui" e `Unauthorized` é "a senha não confere". Os dois
 * primeiros levam ao mesmo lugar; usamos o `-1002` por ser o mais específico dos dois.
 */
const ERRO_MARCA = -1000;
const ERRO_NAO_AUTORIZADO = -1002;
const ERRO_NAO_ENCONTRADO = -1005;

/** A resposta de erro que o jogo entende. */
function erro(int $codigo): string
{
    return ERRO_MARCA . ';' . $codigo . ';';
}

/** O `zid` é o número público, o que aparece na tela. Começa alto para parecer o que era. */
const ZID_BASE = 100000;

function esquema(PDO $pdo): void
{
    $pdo->exec('CREATE TABLE IF NOT EXISTS bonecos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        zid INTEGER,
        imei TEXT, senha_md5 TEXT, apelido TEXT, genero INTEGER,
        aniversario TEXT, criador TEXT, status INTEGER,
        campos TEXT NOT NULL,
        recebido_em TEXT)');
}

/**
 * Guarda um boneco exportado e devolve `[id, zid]`.
 *
 * Reexportar o mesmo boneco — mesmo criador, mesmo apelido — atualiza em vez de duplicar. Sem
 * isso, cada teste criaria um boneco novo e a lista viraria lixo em poucas tentativas.
 */
function guardar(array $campos): array
{
    $pdo = banco();
    if ($pdo === null) {
        return guardar_em_arquivo($campos);
    }
    esquema($pdo);
    $imei = $campos[CAMPO_CRIADOR_IMEI] ?? '';
    $apelido = $campos[CAMPO_APELIDO] ?? '';

    $busca = $pdo->prepare('SELECT id FROM bonecos WHERE imei = ? AND apelido = ?');
    $busca->execute([$imei, $apelido]);
    $id = $busca->fetchColumn();

    $valores = [
        $imei,
        $campos[CAMPO_SENHA] ?? '',
        $apelido,
        (int) ($campos[CAMPO_GENERO] ?? 0),
        $campos[CAMPO_ANIVERSARIO] ?? '',
        $campos[CAMPO_CRIADOR] ?? '',
        (int) ($campos[CAMPO_STATUS] ?? 0),
        implode(';', $campos),
        gmdate('c'),
    ];
    if ($id === false) {
        $pdo->prepare('INSERT INTO bonecos
            (imei, senha_md5, apelido, genero, aniversario, criador, status, campos, recebido_em)
            VALUES (?,?,?,?,?,?,?,?,?)')->execute($valores);
        $id = (int) $pdo->lastInsertId();
    } else {
        $id = (int) $id;
        $pdo->prepare('UPDATE bonecos SET imei=?, senha_md5=?, apelido=?, genero=?,
            aniversario=?, criador=?, status=?, campos=?, recebido_em=? WHERE id=?')
            ->execute([...$valores, $id]);
    }
    $zid = ZID_BASE + $id;
    $pdo->prepare('UPDATE bonecos SET zid = ? WHERE id = ?')->execute([$zid, $id]);
    return [$id, $zid];
}

/**
 * O boneco de `id`, se a senha bater, com o `id` e o `zid` já preenchidos na lista.
 *
 * A senha chega em MD5 — é assim que o jogo a manda no `export`, e não há motivo para ele mandar
 * diferente aqui. Comparar em MD5 dos dois lados evita guardar senha em claro.
 *
 * Devolve a lista quando acha, `false` quando a senha não confere e `null` quando não existe —
 * três respostas porque o jogo distingue os dois erros, e mostrar "senha errada" para um boneco
 * que não existe entregaria quais ids existem.
 */
function buscar(int $zid, string $senha): string|false|null
{
    $pdo = banco();
    if ($pdo === null) {
        return buscar_em_arquivo($zid, $senha);
    }
    esquema($pdo);
    $linha = $pdo->prepare('SELECT id, zid, senha_md5, campos FROM bonecos WHERE zid = ?');
    $linha->execute([$zid]);
    $achado = $linha->fetch(PDO::FETCH_ASSOC);
    if ($achado === false) {
        return null;
    }
    if ($senha !== '' && strcasecmp($senha, (string) $achado['senha_md5']) !== 0) {
        return false;
    }
    return lista_com_numeros((string) $achado['campos'], (int) $achado['id'], (int) $achado['zid']);
}

/** A lista do boneco com o `id` e o `zid` que o servidor atribuiu. */
function lista_com_numeros(string $campos, int $id, int $zid): string
{
    $lista = explode(';', $campos);
    $lista[CAMPO_ID] = (string) $id;
    if (isset($lista[1])) {
        $lista[1] = (string) $zid;
    }
    return implode(';', $lista);
}

/**
 * O mesmo, num arquivo, para quando o PHP não tem SQLite.
 *
 * Nem toda instalação traz o `pdo_sqlite` habilitado, e este servidor não pode depender disso:
 * ele existe para receber e devolver bonecos, e um `import` que falha por causa de uma extensão
 * ausente não ensina nada sobre o protocolo. O formato é uma linha JSON por boneco.
 */
function arquivo_dos_bonecos(): string
{
    return diretorio_var() . '/bonecos.json';
}

function ler_bonecos(): array
{
    $bruto = @file_get_contents(arquivo_dos_bonecos());
    return $bruto === false ? [] : (json_decode($bruto, true) ?: []);
}

function guardar_em_arquivo(array $campos): array
{
    $bonecos = ler_bonecos();
    $imei = $campos[CAMPO_CRIADOR_IMEI] ?? '';
    $apelido = $campos[CAMPO_APELIDO] ?? '';

    // Reexportar o mesmo boneco atualiza, como no caminho com banco.
    $id = null;
    foreach ($bonecos as $chave => $boneco) {
        if (($boneco['imei'] ?? null) === $imei && ($boneco['apelido'] ?? null) === $apelido) {
            $id = (int) $chave;
            break;
        }
    }
    $id ??= count($bonecos) + 1;
    $bonecos[(string) $id] = [
        'imei' => $imei,
        'senha_md5' => $campos[CAMPO_SENHA] ?? '',
        'apelido' => $apelido,
        'zid' => ZID_BASE + $id,
        'campos' => implode(';', $campos),
        'recebido_em' => gmdate('c'),
    ];
    file_put_contents(arquivo_dos_bonecos(), json_encode($bonecos, JSON_PRETTY_PRINT));
    return [$id, ZID_BASE + $id];
}

function buscar_em_arquivo(int $zid, string $senha): string|false|null
{
    foreach (ler_bonecos() as $id => $boneco) {
        if ((int) ($boneco['zid'] ?? 0) !== $zid) {
            continue;
        }
        if ($senha !== '' && strcasecmp($senha, (string) $boneco['senha_md5']) !== 0) {
            return false;
        }
        return lista_com_numeros((string) $boneco['campos'], (int) $id, $zid);
    }
    return null;
}

/** A lista como o jogo a exportou, sem substituir campo nenhum. */
function original(int $zid): string
{
    $pdo = banco();
    if ($pdo !== null) {
        esquema($pdo);
        $linha = $pdo->prepare('SELECT campos FROM bonecos WHERE zid = ?');
        $linha->execute([$zid]);
        return (string) ($linha->fetchColumn() ?: '');
    }
    foreach (ler_bonecos() as $boneco) {
        if ((int) ($boneco['zid'] ?? 0) === $zid) {
            return (string) $boneco['campos'];
        }
    }
    return '';
}
