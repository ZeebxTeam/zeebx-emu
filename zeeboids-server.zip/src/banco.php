<?php
/**
 * O banco do servidor. SQLite, pelo mesmo motivo do jogo: é um arquivo, e um arquivo se apaga
 * quando o experimento errou.
 *
 * O esquema guarda o **corpo cru** de cada requisição, e não os campos separados. A ordem dos
 * campos dentro da linha ainda é hipótese (docs/protocolo.md), e gravar campos separados agora
 * seria congelar essa hipótese no banco — quando ela for confirmada, dá para reprocessar o que
 * já chegou.
 */

/**
 * O banco, ou `null` quando não dá para abrir.
 *
 * Devolver `null` em vez de estourar é deliberado. O SQLite no PHP depende da extensão
 * `pdo_sqlite`, que em algumas distribuições não vem habilitada com o pacote — e a primeira vez
 * que este servidor recebeu uma requisição de verdade foi exatamente isso que aconteceu: o
 * registro foi gravado e a resposta virou 500.
 *
 * O registro é a razão de o servidor existir agora. Ele não pode depender de uma extensão
 * opcional, e uma requisição registrada com resposta pobre vale muito mais do que um 500.
 */
function banco(): ?PDO
{
    static $pdo = null;
    static $tentou = false;
    if ($tentou) {
        return $pdo;
    }
    $tentou = true;
    if (!class_exists('PDO') || !in_array('sqlite', PDO::getAvailableDrivers(), true)) {
        return null;
    }
    try {
        $pdo = abre();
    } catch (Throwable $e) {
        registrar_nota('sem banco: ' . $e->getMessage());
        $pdo = null;
    }
    return $pdo;
}

/** Um contador em arquivo, para quando não há banco: o export precisa devolver um id. */
function proximo_id(): int
{
    $arquivo = diretorio_var() . '/proximo_id';
    $n = 1 + (int) @file_get_contents($arquivo);
    @file_put_contents($arquivo, (string) $n);
    return $n;
}

function abre(): PDO
{
    $dir = diretorio_var();
    if (!is_dir($dir)) {
        mkdir($dir, 0o755, true);
    }
    $pdo = new PDO('sqlite:' . $dir . '/zeeboids.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec('CREATE TABLE IF NOT EXISTS exportados (
        id INTEGER PRIMARY KEY AUTOINCREMENT, recebido_em TEXT, corpo TEXT)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS sincronizacoes (
        id INTEGER PRIMARY KEY AUTOINCREMENT, recebido_em TEXT, imei TEXT, corpo TEXT)');
    return $pdo;
}
