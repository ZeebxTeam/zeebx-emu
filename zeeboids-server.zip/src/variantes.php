<?php
/**
 * As respostas candidatas, uma por requisição.
 *
 * O formato da resposta é a única parte do protocolo que **não** se lê no binário. O que se sabe
 * do tratador em `0x85b44` é pouco e preciso:
 *
 * - é texto separado por `;`, recebido já fatiado num vetor de campos;
 * - o campo 0 passa pelo `atoi`;
 * - `-1000` nele muda o caminho inteiro, e o ramo do `-1000` segue lendo o campo 1.
 *
 * O resto se descobre testando. Em vez de pedir que alguém edite o código entre uma tentativa e
 * outra, cada requisição usa a variante seguinte e o registro diz qual foi — assim uma sessão de
 * quatro exportações cobre as quatro hipóteses, na ordem.
 *
 * O contador vive em `var/variante`. Apagar o arquivo recomeça do zero.
 */

const VARIANTES = [
    'export.php' => [
        // Lido no código, não mais suposto: o desserializador do jogo lê **três** números em
        // sequência — para `+0x2c`, `+0x30` e `+0x34` — e os entrega a `0x66dcc`, que faz
        // `UPDATE zeeboids SET id=%d, zid=%d, usable=1 WHERE lid=%d` com eles nesta ordem:
        // lid, id, zid.
        //
        // O `lid` é o identificador local, que só o console conhece: ele vem no pedido e o
        // servidor o devolve. Enquanto respondíamos `id;zid`, o jogo lia o `id` como `lid` e o
        // `zid` como `id`, e ficava sem `zid` — daí o boneco sem número e com as opções
        // bloqueadas.
        ['{lid};{id};{zid};', 'lid;id;zid — a ordem que o UPDATE do jogo consome'],
    ],
    'import.php' => [
        // O export provou que a resposta começa por `lid;id;zid` — o desserializador lê três
        // números e os entrega ao `UPDATE zeeboids SET id=%d, zid=%d WHERE lid=%d`. O import
        // cria um boneco local novo e precisa dos mesmos três, com o `lid` que ele acabou de
        // reservar e manda no campo 2 do pedido.
        //
        // Sem eles, o jogo lia o IMEI como `lid` e criava um registro fantasma com id 0 — que
        // depois derrubava o Zeebo F.C. ao listar os bonecos.
        ['{lid};{id};{zid};{dados}', 'lid;id;zid e depois os dados do boneco'],
    ],
    'synchronize.php' => [
        // O `-90` fecha a mensagem no pedido, e o leitor da resposta também o testa — é a
        // âncora mais firme que se tem. Sozinho, deveria dizer "acabou, sem nada".
        ['-90;', 'só o fim de mensagem'],
        // Com o cabeçalho numérico que o leitor espera em modo 0 (`0xa5634` guarda dois números
        // antes de qualquer marcador).
        ['0;0;-90;', 'cabeçalho de dois números e o fim'],
        // Abrindo e fechando a seção de registros sem conteúdo.
        ['-40;-90;', 'seção de registros vazia'],
        // O esqueleto do pedido, espelhado.
        ['-5;-10;-15;-25;-90;', 'o esqueleto do pedido, espelhado'],
    ],
];

/** A resposta desta vez, e a descrição dela. Avança o contador. */
function variante(string $endpoint): array
{
    $lista = VARIANTES[$endpoint] ?? null;
    if ($lista === null) {
        return ['', 'sem variantes para este endpoint'];
    }
    $arquivo = diretorio_var() . '/variante-' . $endpoint;
    $n = (int) @file_get_contents($arquivo);
    @file_put_contents($arquivo, (string) (($n + 1) % count($lista)));
    return $lista[$n % count($lista)];
}
