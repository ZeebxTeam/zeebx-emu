<?php
/**
 * O registro é a razão de este servidor existir agora.
 *
 * O protocolo do Zeeboids está levantado do binário do jogo (docs/protocolo.md), mas o que sobra
 * — a ordem exata dos campos, o formato da resposta, se há autenticação além do IMEI — só se
 * descobre vendo o que chega. Então cada requisição é gravada crua, antes de qualquer tentativa
 * de interpretá-la, e uma resposta errada não apaga o que foi recebido.
 */

/**
 * A chave com que o Zeeboids cifra o corpo antes de enviar.
 *
 * O corpo não chega em texto: o jogo passa por `ICipher1` (AES-128-CBC, IV zerado) antes do
 * POST, e o servidor recebe ruído. A chave é fixa, está no próprio jogo, e foi lida no emulador
 * quando ele a configura pelo `ICipher1::SetParam` — o relatório do Zeebx a imprime na seção
 * `cifra:`.
 *
 * Decifrar aqui é o que faz o registro valer alguma coisa: sem isto ele guarda bytes opacos.
 */
const CHAVE = "\x00\x01\x02\x03\x05\x06\x07\x08\x0a\x0b\x0c\x0d\x0f\x10\x11\x12";

/**
 * O envelope, desmontado: `deflate(texto) + IMEI de 15 caracteres + NUL`, tudo cifrado.
 *
 * A compressão foi a última peça a aparecer, e explica por que o claro parecia ruído: são 209
 * bytes de `deflate` cru que viram 399 de texto separado por `;`. O binário do jogo traz
 * `SOURCE~1\gzip.cpp`, que era a pista.
 *
 * Devolve `[texto, imei]`, com `texto` em `null` se a descompressão falhar.
 */
function desmonta(string $claro): array
{
    $sem_zeros = rtrim($claro, "\0");
    if (strlen($sem_zeros) <= 15) {
        return [null, null];
    }
    $imei = substr($sem_zeros, -15);
    $carga = substr($sem_zeros, 0, -15);
    $texto = @gzinflate($carga);
    return [$texto === false ? null : $texto, $imei];
}

/**
 * Os IVs conhecidos, na ordem em que se tenta.
 *
 * O jogo define o IV pelo `ICipher1::SetParam`, e ele **não é sempre zero**. O segundo desta
 * lista foi recuperado de um par claro/cifrado conhecido — com o claro que o emulador registra e
 * o cifrado que chegou aqui, `IV = D(C₀) ⊕ P₀` —, e confere bloco a bloco em todas as
 * exportações capturadas.
 *
 * Tentar mais de um é o certo justamente porque IV errado **não parece** erro: em CBC ele
 * corrompe só o primeiro bloco, e o fim da mensagem sai legível. Quem decide qual acertou é a
 * descompressão.
 */
const IVS = [
    // O que o jogo usa. Vem primeiro porque é o certo na prática, e porque a escolha **não pode
    // ser decidida pelo conteúdo**: com o IV errado o `deflate` costuma decodificar assim mesmo
    // e devolver texto plausível — um MD5 virou `G0CA427<A0F927<2...` num teste, e nem exigir
    // texto imprimível nem exigir fim de fluxo limpo separaram os dois casos.
    "\x00\x00\x00\x01\x01\x00\x00\x00\x00\x01\x01\x00\x00\x01\x00\x00",
    // Zero, que aparece em mensagens do emulador quando o jogo ainda não configurou o cifrador.
    "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
];

/** O corpo em claro e a carga descomprimida, tentando os IVs conhecidos. */
function decifra(string $corpo): ?string
{
    if ($corpo === '' || strlen($corpo) % 16 !== 0 || !function_exists('openssl_decrypt')) {
        return null;
    }
    $primeiro = null;
    foreach (IVS as $iv) {
        $claro = openssl_decrypt($corpo, 'aes-128-cbc', CHAVE, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $iv);
        if ($claro === false) {
            continue;
        }
        $primeiro ??= $claro;
        // Descomprimir é o mínimo, não a prova. Ver a nota em IVS: o primeiro da lista é o que
        // o jogo usa, e é ele que decide quando os dois "funcionam".
        $texto = desmonta($claro)[0];
        if ($texto !== null && $texto !== '' && !preg_match('/[^\x20-\x7e]/', $texto)) {
            return $claro;
        }
    }
    return $primeiro;
}

/**
 * Onde ficam registro e banco.
 *
 * O `ZEEBOIDS_VAR` existe porque a porta 80 pede privilégio: o servidor que atende o jogo roda
 * como root e deixa o diretório dele de root, e aí uma segunda instância rodando como usuário
 * comum não consegue escrever. Poder apontar o diretório resolve sem `sudo` e sem `chown`.
 */
function diretorio_var(): string
{
    return getenv('ZEEBOIDS_VAR') ?: dirname(__DIR__) . '/var';
}

function caminho_do_log(): string
{
    $dir = diretorio_var();
    if (!is_dir($dir)) {
        mkdir($dir, 0o755, true);
    }
    return $dir . '/requisicoes.log';
}

/** A carga em campos da última requisição registrada, ou `null`. */
function campos_da_requisicao(): ?array
{
    static $campos = null;
    if (func_num_args()) {
        $campos = func_get_arg(0);
    }
    return $campos;
}

/** Grava a requisição inteira e devolve o corpo cru. */
function registrar(string $endpoint): string
{
    $corpo = file_get_contents('php://input');

    $cabecalhos = [];
    foreach ($_SERVER as $chave => $valor) {
        if (str_starts_with($chave, 'HTTP_') || $chave === 'CONTENT_TYPE' || $chave === 'CONTENT_LENGTH') {
            $cabecalhos[] = "  $chave: $valor";
        }
    }
    sort($cabecalhos);

    $linhas = [
        str_repeat('=', 72),
        gmdate('Y-m-d H:i:s') . "  $endpoint  " . ($_SERVER['REQUEST_METHOD'] ?? '?'),
        implode("\n", $cabecalhos),
        '  corpo (' . strlen($corpo) . ' bytes):',
        '    ' . str_replace("\n", "\n    ", var_export($corpo, true)),
    ];

    // O corpo é texto com campos separados por ponto e vírgula, mas isso é o que se **espera**.
    // Se vier outra coisa, o despejo em hexadecimal é o que vai dizer.
    if ($corpo !== '' && !ctype_print(str_replace([";", "\n", "\r"], '', $corpo))) {
        $linhas[] = '  não é texto imprimível; em hexadecimal:';
        $linhas[] = '    ' . chunk_split(bin2hex($corpo), 64, "\n    ");
    } elseif ($corpo !== '') {
        $campos = explode(';', $corpo);
        $linhas[] = '  ' . count($campos) . ' campo(s) separado(s) por ";":';
        foreach ($campos as $i => $campo) {
            $linhas[] = sprintf('    [%2d] %s', $i, var_export($campo, true));
        }
    }

    // O corpo em claro vem por último, porque é interpretação: se a chave mudar, o que está
    // acima continua sendo o que chegou.
    $claro = decifra($corpo);
    if ($claro !== null) {
        [$texto, $imei] = desmonta($claro);
        $linhas[] = '  IMEI do console: ' . var_export($imei, true);
        if ($texto === null) {
            // Quase sempre é o IV, e não a chave. O jogo reaproveita o objeto de cifra, então o
            // IV de uma mensagem é o último bloco cifrado da anterior — e nem toda mensagem
            // anterior passa por aqui. Em CBC um IV errado corrompe **só o primeiro bloco**, que
            // é justamente onde o `deflate` começa: o IMEI e os zeros do fim saem legíveis e dão
            // a impressão de que decifrou.
            //
            // Quem quiser o claro sem essa incerteza: o emulador o registra na seção `cifrado:`,
            // porque o corpo passa por ele antes de ser cifrado.
            $linhas[] = '  decifrado com IV zero, mas a carga não descomprimiu — provável';
            $linhas[] = '  encadeamento de IV vindo de uma mensagem anterior:';
            $linhas[] = '    ' . bin2hex($claro);
        } else {
            campos_da_requisicao(explode(';', $texto));
            $linhas[] = '  carga (deflate -> ' . strlen($texto) . ' bytes):';
            foreach (explode(';', $texto) as $i => $campo) {
                $linhas[] = sprintf('      [%2d] %s', $i, var_export($campo, true));
            }
        }
    }

    file_put_contents(caminho_do_log(), implode("\n", $linhas) . "\n", FILE_APPEND);
    return $corpo;
}

/** Uma linha solta no registro, para contar o que aconteceu do lado do servidor. */
function registrar_nota(string $texto): void
{
    file_put_contents(caminho_do_log(), "  ! $texto\n", FILE_APPEND);
}

/** Responde como o jogo espera: corpo binário opaco, sem cabeçalho a mais. */
function responder(string $corpo): void
{
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . strlen($corpo));
    echo $corpo;
}
