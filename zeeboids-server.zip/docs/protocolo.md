# O protocolo do Zeeboids

Levantado do binário do jogo (`zeeboids.mod`, 1,1 MB) com o emulador Zeebx. Tudo o que está aqui
é **lido do binário**, não suposto — onde há inferência, está dito.

O servidor original (`www.zeeboids.com`) saiu do ar com a TecToy. Este documento é o que se
precisa para escrever outro.

## Os três endereços

Aparecem literais no binário:

| Endereço no binário | URL |
|---|---|
| `0x061ab0` | `http://www.zeeboids.com/zeeboidsService/PHP/Client/import.php` |
| `0x0b197c` | `http://www.zeeboids.com/zeeboidsService/PHP/Client/export.php` |
| `0x0b1b2c` | `http://www.zeeboids.com/zeeboidsService/PHP/Client/synchronize.php` |

O código que os usa está em `ZeeboidAccess.cpp` — o caminho do fonte ficou no binário, junto com
`ZeeboidModel.cpp` e `Zeeboid.cpp`.

## O transporte

Três strings, e só três, descrevem a requisição:

```
POST
X-Method: POST
Content-Type: application/octet-stream
```

Não há `<?xml`, `soap`, `multipart` nem `charset` em lugar nenhum do módulo. **Não é XML nem
formulário**: é um POST com corpo binário opaco para o HTTP.

## O corpo, resolvido

O envelope tem três camadas, e foram descobertas nesta ordem — cada uma escondendo a seguinte:

```
AES-128-CBC( deflate(texto separado por ";") + IMEI[15] + NUL + zeros até múltiplo de 16 )
```

- **A cifra** é AES-128-CBC com chave fixa `00010203050607080a0b0c0d0f101112`, que está no
  próprio jogo e passa pelo `ICipher1::SetParam`. **O IV só é zero na primeira mensagem**: o jogo
  reaproveita o objeto de cifra, e o IV de uma mensagem é o último bloco cifrado da anterior —
  medido, o IV final de um cifrador era exatamente o último bloco da mensagem que ele acabara de
  cifrar. Como nem toda cifragem anterior vira requisição HTTP, o servidor muitas vezes **não
  tem como saber o IV**.

  Isso engana: em CBC um IV errado corrompe só o primeiro bloco, e o IMEI e os zeros do fim saem
  legíveis. Parece que decifrou, e só a descompressão denuncia.

  **Para estudar o protocolo, use o claro do emulador** — a seção `cifrado:` do relatório —, que
  vê o corpo antes de ele ser cifrado e não depende de adivinhar IV.
- **A compressão** é `deflate` cru — sem cabeçalho `zlib` nem `gzip`. Foi a última peça a
  aparecer e explica por que o claro parecia ruído: 209 bytes comprimidos viram 399 de texto. O
  binário traz `SOURCE~1\gzip.cpp`, que era a pista que ficou sem uso por muito tempo.
- **O IMEI** vai fora da compressão, como quinze caracteres ASCII colados no fim.

Quem quiser ver isso sem decifrar nada: o emulador registra o claro na seção `cifrado:` do
relatório, porque o corpo passa por ele antes de ser cifrado.

## Um `export` inteiro, lido

Esta é uma exportação real, do log do emulador, descomprimida:

```
350000000000006;1;-2;202CB962AC59075B964B07152D234B70;350000000000006;kaio;1;
01/01/1980;criador;1;0;0;1;0;0;-1386310;2;12;0;0;3;23;0;-1104947445;...
```

Os dez primeiros campos são o Zeeboid, e batem com o esquema do banco local:

| # | Valor | Coluna |
|---:|---|---|
| 0 | `350000000000006` | IMEI do console |
| 1 | `1` | ainda sem nome |
| 2 | `-2` | `id` — negativo enquanto o boneco não foi exportado |
| 3 | `202CB962AC59075B964B07152D234B70` | `password`, **em MD5** |
| 4 | `350000000000006` | `creator_IMEI` |
| 5 | `kaio` | `nickname` |
| 6 | `1` | `gender` |
| 7 | `01/01/1980` | `birthday` |
| 8 | `criador` | `creator_name` |
| 9 | `1` | `status` |

O campo 3 é o resumo MD5 da senha: `202CB962AC59075B964B07152D234B70` é o MD5 de `123`, que foi
a senha digitada. Isso confirma de uma vez a classe `0x01001015` do emulador, que estava com a
tabela de slots errada até pouco antes desta captura.

Depois vêm as **peças do avatar**, cada uma aberta por um identificador de 1 a 11, seguido dos
campos dela — o que casa com as onze tabelas `zeeboid_*` do banco local. Os números grandes são
**floats IEEE-754 guardados como inteiros com sinal**:

```
-1104947445 -> -0.16      1067903358 -> 1.304
-1085485817 -> -0.80      1042401987 ->  0.158
 1065353216 ->  1.00      1036831949 ->  0.100
```

São as posições e escalas de cada peça — os `position_y`, `scale` e `rotation` do esquema.

## Os formatos com `;` do binário

Os formatos de `sprintf` levantados do módulo — `%d;%s`, `%d;%d;%d;` e os outros — são o que
monta **este texto**, antes da compressão. A leitura original estava certa quanto a eles; o que
faltava era saber que o resultado ainda passa por `deflate` e por AES.

| Endereço | Formato | Campos |
|---|---|---:|
| `0x061aa8` | `%d;%s` | 2 |
| `0x0559bc` | `%d;` | 1 |
| `0x055c3c` | `%d;%d;` | 2 |
| `0x05cb6c` | `%d;%d;%d;` | 3 |
| `0x0598f8` | `%d;%d;%d;%d;` | 4 |
| `0x05a040` | `%d;%d;%d;%d;%d;` | 5 |
| `0x05cf70` | `%d;%d;%d;%s;%d;` | 5 |
| `0x05a3e0` | `%d;%d;%d;%d;%d;%d;` | 6 |
| `0x059c88` | `%d;%d;%d;%d;%d;%d;%d;` | 7 |
| `0x05cb4c` | `%d;%d;%s;%s;%s;%d;%s;%s;%d;` | 9 |

## O `import`, de uma captura real

O pedido **não é** `id;senha`, como este documento supunha a partir do formato `%d;%s` colado na
URL do endpoint. É:

```
0 ; 350000000000006 ; -5 ; 100001 ; 6512BD43D9CAA6E02C990B0A82652DCA
?        IMEI         lid    ZID              senha em MD5
```

A busca é pelo **`zid`** — o número público, o que o jogador digita — e não pelo `id` interno.
Faz sentido: o `id` ninguém vê.

Essa captura prova outra coisa, de graça: o `100001` que o jogo pede importar é o **`zid` que o
servidor atribuiu** no `export` minutos antes. Ou seja, **o jogo aceitou a resposta do `export`**,
guardou o número e o usou.

### Os erros têm código, e cada um tem uma tela

A resposta de erro é `-1000;<código>;` — o campo 0 igual a `-1000` diz "deu errado" e o campo 1
traz o código, que o jogo guarda e consulta pelo getter em `0x85b28`.

O que cada código mostra saiu da tabela de estados do `ImportScreen`, em `0x7aee8`, cruzada com
os pop-ups que cada tratador abre:

| código | estado | pop-up |
|---|---|---|
| `-1001`, `-1002` | 5 | `Unauthorized` |
| `-1005` | 6 | `NotInOrbit` |
| (sucesso) | 2, 3 | `Complete` |

`NotInOrbit` é "não existe aqui"; `Unauthorized` é "a senha não confere". Responder erros
diferentes para os dois casos também evita dizer quais `zid` existem.

## A resposta do `export`, lida no código

São **três** números: `lid;id;zid;`.

O desserializador do jogo lê três valores em sequência, guardando-os em `+0x2c`, `+0x30` e
`+0x34` (`0xa38ec`, `0xa390c`, `0xa38b8`), e os entrega a `0x66dcc`, que monta exatamente isto:

```sql
UPDATE zeeboids SET id=%d, zid=%d, usable=1 WHERE lid=%d;
```

com os argumentos nessa ordem — `lid` primeiro, depois `id`, depois `zid`.

O `lid` é o identificador **local** do console, que só ele conhece: vem no pedido e o servidor o
devolve, porque é a chave do `UPDATE`.

Ele é o **campo 1** da carga do `export`, não o 2. O campo 2 é o `id`, que chega **negativo**
enquanto o boneco não foi exportado — `-2` na captura —, e esse padrão é o que distingue os dois.
Trocá-los faz o `UPDATE` procurar uma linha que não existe: o servidor responde certo, o jogo
aceita, e o boneco continua sem número.

Isto corrige o palpite antigo de `id;zid`, e explica o sintoma que ele causava: o jogo lia o
`id` como `lid` e o `zid` como `id`, ficava sem `zid`, e o boneco aparecia sem número e com as
opções bloqueadas.

## A resposta do `import` também começa pelo trio

Pelo mesmo motivo do `export`: o desserializador lê três números e os entrega ao `UPDATE`. O
`import` cria um boneco **local novo** e precisa dos mesmos três — com o `lid` que o console
acabou de reservar e manda no **campo 2 do pedido**.

```
pedido:   0;350000000000006;-5;100001;C4CA4238A0B923820DCC509A6F75849B
                             ^^          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                             lid                 senha em MD5

resposta: -5;1;100001;<senha>;<IMEI>;<apelido>;<gênero>;<aniversário>;…
          ^^^^^^^^^^^
          lid;id;zid
```

Sem o trio, o jogo lia o IMEI como `lid` e criava **um registro fantasma com id 0** — que depois
derrubava o Zeebo F.C. ao listar os bonecos, com acesso inválido a zero. Os dois sintomas eram a
mesma causa.

## O `synchronize`: o pedido ensina o vocabulário

O pedido usa os mesmos marcadores negativos da resposta, e comparando um sync com dados e um sem
o esqueleto aparece:

```
vazio:  IMEI;-5;1;2;-10;11;-15;-25;-90
cheio:  IMEI;16;18;-5;1;2;-10;2;12;0;0;11;51;0;52;0;…;-15;194;233203;189;1516594530;…;-25;-90
```

- `-5`, `-10`, `-15`, `-25` **abrem seções**; o que vem depois de cada um é o conteúdo dela.
- Depois do `-15` vêm **pares `id;valor`** — são os placares que o jogo está enviando.
- **`-90` fecha a mensagem.**

O `-90` está nos dois vocabulários — o do pedido e o do leitor da resposta —, então é o fim nas
duas direções. É a primeira âncora firme que se tem do formato de resposta.

## O `synchronize`: a resposta é uma máquina de estados

Diferente do `export` e do `import`, que respondem uma lista simples, o `synchronize` devolve um
**fluxo com marcadores**. O leitor do jogo mantém um modo em `+0x2c` e um contador de campo em
`+0x24`, e certos números negativos trocam o modo em vez de virarem dado.

Os marcadores, levantados varrendo os `cmn` da região do leitor (`0xa3800`–`0xa5d00`):

| Marcador | Onde | O que faz |
|---:|---|---|
| `-20` | `0xa4fb4` | modo 3 |
| `-30` | `0xa5588` | fim de registro |
| `-35` | `0xa554c` | modo 3 |
| `-40` | `0xa5640`, `0xa38e4` | **modo 1** — abre a leitura de registros |
| `-45` | `0xa4164` | reinicia o contador |
| `-50` | `0xa40e0` | |
| `-55` a `-95` | vários | seções de conquistas, vizinhos e placares |
| `-1004` | `0xa43b4` | erro do `export` |

O primeiro campo do fluxo é lido em modo 0 (`0xa5634`): se for `-40`, troca para o modo 1; senão
é guardado como número em `+0x30`, e o seguinte em `+0x34`. Ou seja, **começa por um cabeçalho
numérico** e só então entram as seções.

As três tabelas que essa resposta alimenta têm cada uma o seu montador de `INSERT`, e a ordem dos
argumentos dele dá a ordem dos campos:

| Tabela | Montador | Colunas |
|---|---|---|
| `scores_top10` | `0x66ab8` | `zid, nickname, score_id, score_value` |
| `scores_zeeboid_neighbours` | via `0x6952c` | `id, rank, zid, nickname, score_id, score_value` |
| `zeeboid_achievement` | via `0x6ad70` | `lid, achievement_id, tasks_completed, updated, completed` |

O consumidor do `top10` (`0xa54cc`) confirma a forma: acumula em `+0x40`…`+0x54` e chama o
`INSERT` quando o registro fecha.

Falta amarrar marcador a seção, e é o que as variantes do `synchronize` existem para descobrir.

## A resposta: o que já se sabe, lido no código

A requisição vai cifrada; **a resposta não**. O tratador do estado "recebendo dados"
(`0x85b44`) mostra o formato:

```
0x85b50  ldr r0, [r0, #8]     ; a contagem de campos; zero é "não veio nada"
0x85b70  ldr r0, [r4, #4]     ; o vetor de campos
0x85b78  ldr r0, [r0]         ; o campo 0
0x85b7c  ldr r1, [r1, #0x90]  ; helper 36 = atoi
0x85b80  blx r1
0x85b84  cmn r0, #0x3e8       ; compara com -1000
```

Daí saem três fatos:

1. **É texto separado por `;`**, e o jogo o recebe já fatiado num vetor de campos.
2. **O campo 0 é numérico** — passa direto pelo `atoi`.
3. **`-1000` é um valor especial** nesse campo: o caminho muda inteiro conforme ele seja ou não
   `-1000`, e o ramo do `-1000` segue lendo o campo 1.

Isso corrige o palpite anterior de que o `export` responderia `id;zid;`. O mais provável é
**`status;id;zid;`**, com um código na frente. Os endpoints deste repositório ainda respondem o
palpite antigo, e está assim de propósito: trocar por outro palpite não melhora nada.

O que falta para confirmar é entregar a resposta ao jogo, e isso é trabalho do lado do emulador —
o vetor de campos é de strings que o alocador do próprio jogo possui, então preenchê-lo com
memória de fora dispara o `TTDMM ASSERT` dele. Medido.

## O que ainda falta descobrir

- **O primeiro campo do pedido de import**, que veio `0` na única captura.
- **A ordem exata dos campos** de cada linha. A do `synchronize` já se sabe começar pelo IMEI e
  seguir por linhas repetidas; falta a ordem dentro da linha, que as contagens fazem casar com as
  tabelas mas por analogia.
- **O formato da resposta.** O jogo tem `Handling HTTP redirect` no log, então trata redirecionamento;
  o resto se descobre observando.
- **Autenticação**, se houver além de `id;senha` e do `creator_IMEI`.

Tudo isso se resolve do mesmo jeito: subir um servidor que registre o que chega. O emulador
precisa da pilha de rede para isso — é o próximo passo do lado dele.

## Como testar

Redirecionar o domínio para a máquina local resolve o endereço sem tocar no jogo:

```
127.0.0.1  www.zeeboids.com
```

Vale lembrar que o jogo usa **HTTP**, não HTTPS, o que simplifica: basta o servidor na porta 80.
